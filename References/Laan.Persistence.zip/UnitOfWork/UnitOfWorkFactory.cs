using System;
using System.Diagnostics;
using System.Collections.Generic;

using Castle.Core.Logging;

using NHibernate;
using NHibernate.Cfg;

using Castle.Facilities.NHibernateIntegration;
using Laan.Persistence.Interfaces;

namespace Laan.Persistence
{
    public class UnitOfWorkFactory : IUnitOfWorkFactory
    {
        private readonly ILogger _logger;
        private readonly ISessionManager _manager;
        private string _alias;

        private Dictionary<string, IUnitOfWork> _units;

        public UnitOfWorkFactory( ILogger logger, ISessionManager manager )
        {
            _logger = logger;
            _manager = manager;
            _units = new Dictionary<string, IUnitOfWork>();
            _alias = "";
        }

        private bool UnitOfWorkNotDefined( string alias )
        {
            var threadSafeAlias = GetThreadSafeAlias( alias );

            bool unitsContainsKey = _units != null && _units.ContainsKey( threadSafeAlias );
            bool result =
                !unitsContainsKey || 
                ( unitsContainsKey && _units[ threadSafeAlias ].RefCount == 0 ) ||
                ( unitsContainsKey && !_units[ threadSafeAlias ].Session.IsOpen );

            return result;
        }

        private void CreateUnitOfWork( string alias )
        {
            UnitOfWork unitOfWork;
            var threadSafeAlias = GetThreadSafeAlias( alias );
            _alias = alias;

            _manager.DefaultFlushMode = FlushMode.Never;
            if ( String.IsNullOrEmpty( alias ) )
                unitOfWork = new UnitOfWork( _logger, _manager.OpenSession(), this, alias );
            else
                unitOfWork = new UnitOfWork( _logger, _manager.OpenSession( alias ), this, alias );

            _units[ threadSafeAlias ] = unitOfWork;
        }

        public IUnitOfWork UnitOfWork( string alias )
        {
            var threadSafeAlias = GetThreadSafeAlias( alias );

            if ( UnitOfWorkNotDefined( alias ) )
                CreateUnitOfWork( alias );
            else
                _units[ threadSafeAlias ].RefCount++;

            return _units[ threadSafeAlias ];
        }

        public IUnitOfWork UnitOfWork()
        {
            return UnitOfWork( _alias );
        }

        public ISession OpenSession()
        {
            if ( UnitOfWorkNotDefined( _alias ) )
                CreateUnitOfWork( _alias );

            return _units[ GetThreadSafeAlias( _alias ) ].Session;
        }

        public void RemoveUnit( string alias )
        {
            var threadSafeAlias = GetThreadSafeAlias( alias );

            if ( _units.ContainsKey( threadSafeAlias ) && _units[ threadSafeAlias ].RefCount != 0 )
                throw new Exception( "RefCount must be zero before removing unit" );

            _units.Remove( threadSafeAlias );
            if ( _alias == alias )
                _alias = "";
        }

        public System.Data.IDbCommand CreateCommand()
        {
            var threadSafeAlias = GetThreadSafeAlias( _alias );
            var session = OpenSession();
            var command = session.Connection.CreateCommand();

            if ( _units.ContainsKey( threadSafeAlias ) )
                _units[ threadSafeAlias ].Enlist( command );

            return command;
        }

        private string GetThreadSafeAlias( string alias )
        {
            return string.Format( "{0}`{1}", alias, System.Threading.Thread.CurrentThread.ManagedThreadId );
        }

        #region IDisposable Members

        public void Dispose()
        {
            foreach ( KeyValuePair<string, IUnitOfWork> unitOfWork in _units )
            {
                ISession session = unitOfWork.Value.Session;
                if ( session != null && session.IsOpen )
                    session.Close();
            }
            _alias = "";
            _units.Clear();
        }

        #endregion
    }
}
