using System;

namespace Laan.Persistence.Interfaces
{
    public interface IMapper
    {
        string MapPath( string path );
    }
}
